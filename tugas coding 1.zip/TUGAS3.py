# soal meng konversi kelvin ke celcius
kelvin = int(input("masukkan suhu kelvin ke celcius ="))
celcius = kelvin-273.15
print ("hasil koversi kelvin ke celcius =", celcius)