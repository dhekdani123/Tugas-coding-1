# soal koversi dari celcius ke fahrenhite
celcius = int(input("masukkan suhu celcius yang akan dikonversi ke fahrenhite ="))
fahrenhite = (9/5*celcius)+32
print ("hasil konversi suhu =", fahrenhite)